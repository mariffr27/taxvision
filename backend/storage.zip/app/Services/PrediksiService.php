<?php

namespace App\Services;

use App\Models\DataPajak;
use App\Models\HasilPrediksi;
use App\Models\HasilPrediksiDetail;
use Carbon\Carbon;

class PrediksiService
{
    /**
     * Melakukan prediksi penerimaan pajak menggunakan metode Simple Moving
     * Average (SMA) murni, dievaluasi dengan MAPE.
     *
     * Sesuai batasan penelitian: metode time series yang digunakan adalah
     * SMA saja (tidak dibandingkan dengan metode lain), dan pengujian
     * dilakukan terhadap BEBERAPA VARIASI PERIODE SMA untuk memperoleh
     * MAPE terkecil. Rumus SMA tidak dimodifikasi.
     *
     * PERUBAHAN dari versi awal:
     * - Variasi periode SMA yang diuji diperluas dari {3, 6, 12} menjadi
     *   seluruh periode 2 s.d. 12 bulan, supaya pencarian periode dengan
     *   MAPE terkecil lebih menyeluruh (sesuai batasan masalah: "pengujian
     *   terhadap beberapa variasi periode SMA").
     * - Data historis digunakan dalam kondisi asli tanpa cap atau koreksi
     *   anomali agar hasil prediksi dan evaluasi MAPE merepresentasikan
     *   nilai penerimaan yang sebenarnya.
     * - Rumus SMA, evaluasi walk-forward, dan MAPE TIDAK diubah dari
     *   definisi standarnya.
     */
    public function prediksiSMA5TahunBulanan(
        int $idJenisPajak,
        int $idModel,
        string $periodePrediksi
    ): array {
        $periode = Carbon::parse($periodePrediksi);

        $startDate = $periode->copy()->subYears(5)->startOfMonth();
        $endDate = $periode->copy()->subMonth()->endOfMonth();

        $dataHistoris = $this->ambilDataHistorisBulananPrioritas(
            $idJenisPajak,
            $startDate,
            $endDate
        );

        if (count($dataHistoris) < 24) {
            throw new \Exception(
                'Minimal diperlukan 24 data bulanan untuk melakukan evaluasi SMA.'
            );
        }

        // Menggunakan data historis asli tanpa cap atau koreksi anomali.
        $dataHistorisBersih = $dataHistoris;

        $splitIndex = (int) floor(count($dataHistorisBersih) * 0.8);
        $train = array_slice($dataHistorisBersih, 0, $splitIndex);
        $test = array_slice($dataHistorisBersih, $splitIndex);

        // ── Pengujian beberapa variasi periode SMA (2-12 bulan) ─────────────
        // Diperluas dari versi awal {3, 6, 12} agar pencarian periode dengan
        // MAPE terkecil lebih menyeluruh, sesuai batasan masalah penelitian.
        $periodeUji = range(2, 12);
        $hasilModel = [];

        foreach ($periodeUji as $periodeSMA) {
            if (count($train) < $periodeSMA) {
                continue;
            }

            $evaluasi = $this->evaluasiSMA($train, $test, $periodeSMA);

            if (empty($evaluasi)) {
                continue;
            }

            $hasilModel[] = [
                'model' => 'SMA ' . $periodeSMA,
                'periode_sma' => $periodeSMA,
                'jumlah_data_training' => count($train),
                'jumlah_data_testing' => count($test),
                'jumlah_data_uji' => count($evaluasi),
                'mape' => $this->hitungMAPE($evaluasi),
                'evaluasi' => $evaluasi,
            ];
        }

        if (empty($hasilModel)) {
            throw new \Exception('Tidak ada periode SMA yang dapat diuji.');
        }

        // Pilih periode SMA terbaik berdasarkan MAPE terkecil
        usort($hasilModel, fn($a, $b) => $a['mape'] <=> $b['mape']);
        $modelTerbaik = $hasilModel[0];
        $periodeTerbaik = $modelTerbaik['periode_sma'];

        // Prediksi final menggunakan seluruh data bersih dan periode SMA terbaik
        $nilaiPrediksi = $this->prediksiSMAFinal($dataHistorisBersih, $periodeTerbaik);

        $nilaiAkurasi = $modelTerbaik['mape'];

        $hasilDB = HasilPrediksi::create([
            'id_jenis_pajak' => $idJenisPajak,
            'id_model' => $idModel,
            'perioda_prediksi' => $periodePrediksi,
            'nilai_prediksi' => round($nilaiPrediksi, 2),
            'metode_akurasi' => 'MAPE',
            'nilai_akurasi' => $nilaiAkurasi,
        ]);
        $periodeTanggal = Carbon::parse($periodePrediksi)->startOfMonth();

        $adaDataAktual = DataPajak::where('id_jenis_pajak', $idJenisPajak)
            ->whereYear('tanggal_pajak', $periodeTanggal->year)
            ->whereMonth('tanggal_pajak', $periodeTanggal->month)
            ->where('sumber_data', 'aktual')
            ->exists();
        if (!$adaDataAktual) {
            DataPajak::updateOrCreate(
                [
                    'id_jenis_pajak' => $idJenisPajak,
                    'tanggal_pajak' => $periodeTanggal->format('Y-m-d'),
                    'sumber_data' => 'prediksi',
                ],
                [
                    'id_user' => request()->user()?->id ?? 1,
                    'jumlah_pendapatan' => round($nilaiPrediksi, 2),
                    'hasil_prediksi_id' => $hasilDB->id,
                ]
            );
        }

        $responseArray = [
            'metode' => 'Simple Moving Average (pengujian beberapa variasi periode)',
            'periode_data' => $startDate->format('Y-m') . ' - ' . $endDate->format('Y-m'),
            'jumlah_data_bulanan' => count($dataHistoris),
            'pembagian_data' => [
                'training' => count($train),
                'testing' => count($test),
                'rasio' => '80:20',
            ],
            'periode_diuji' => $periodeUji,
            'model_diuji' => $hasilModel,
            'model_terbaik' => [
                'model' => $modelTerbaik['model'],
                'periode_sma' => $periodeTerbaik,
                'mape' => $modelTerbaik['mape'],
            ],
            'periode_prediksi' => $periodePrediksi,
            'nilai_prediksi' => round($nilaiPrediksi, 2),
            'hasil_db' => $hasilDB,
            'rumus' => 'F_t = (A_{t-1} + A_{t-2} + ... + A_{t-n}) / n',
        ];

        HasilPrediksiDetail::create([
            'hasil_prediksi_id' => $hasilDB->id,
            'detail_response' => $responseArray,
        ]);

        return $responseArray;
    }

    private function ambilDataHistorisBulananPrioritas(
        int $idJenisPajak,
        Carbon $startDate,
        Carbon $endDate
    ): array {
        return DataPajak::where('id_jenis_pajak', $idJenisPajak)
            ->whereBetween('tanggal_pajak', [$startDate, $endDate])
            ->orderBy('tanggal_pajak', 'asc')
            ->get()
            ->groupBy(function ($item) {
                return Carbon::parse($item->tanggal_pajak)->format('Y-m');
            })
            ->map(function ($items, $periode) {
                $dataAktual = $items->where('sumber_data', 'aktual');

                if ($dataAktual->count() > 0) {
                    $totalPendapatan = $dataAktual->sum('jumlah_pendapatan');
                    $sumberData = 'aktual';
                } else {
                    $dataPrediksi = $items->where('sumber_data', 'prediksi');

                    if ($dataPrediksi->count() === 0) {
                        return null;
                    }

                    $totalPendapatan = $dataPrediksi->sum('jumlah_pendapatan');
                    $sumberData = 'prediksi';
                }

                [$tahun, $bulan] = explode('-', $periode);

                return [
                    'tahun' => (int) $tahun,
                    'bulan' => (int) $bulan,
                    'total_pendapatan' => (float) $totalPendapatan,
                    'sumber_data' => $sumberData,
                ];
            })
            ->filter()
            ->sortBy(function ($item) {
                return $item['tahun'] . '-' . str_pad($item['bulan'], 2, '0', STR_PAD_LEFT);
            })
            ->values()
            ->toArray();
    }

    /**
     * Mengevaluasi model SMA menggunakan walk-forward validation.
     */
    private function evaluasiSMA(array $train, array $test, int $periodeSMA): array
    {
        $history = $train;
        $hasilEvaluasi = [];

        foreach ($test as $row) {
            try {
                $prediksi = $this->prediksiSMAFinal($history, $periodeSMA);
            } catch (\Exception $e) {
                $history[] = $row;
                continue;
            }

            $aktual = $row['total_pendapatan'];

            $hasilEvaluasi[] = [
                'tahun' => $row['tahun'],
                'bulan' => $row['bulan'],
                'aktual' => $aktual,
                'prediksi' => round($prediksi, 2),
                'error' => round($aktual - $prediksi, 2),
                'absolute_percentage_error' => $aktual != 0
                    ? round((abs($aktual - $prediksi) / $aktual) * 100, 2)
                    : 0,
            ];

            $history[] = $row;
        }

        return $hasilEvaluasi;
    }

    /**
     * Menghitung nilai prediksi SMA dari n bulan terakhir.
     * Rumus standar, tidak dimodifikasi: F_t = (A_{t-1} + ... + A_{t-n}) / n
     */
    private function prediksiSMAFinal(array $data, int $periodeSMA): float
    {
        $jumlahData = count($data);

        if ($jumlahData < $periodeSMA) {
            throw new \Exception('Jumlah data tidak cukup untuk menghitung SMA.');
        }

        $total = 0;
        for ($i = 1; $i <= $periodeSMA; $i++) {
            $total += $data[$jumlahData - $i]['total_pendapatan'];
        }

        return $total / $periodeSMA;
    }

    /**
     * Menghitung Mean Absolute Percentage Error (MAPE). Dipertahankan
     * persis seperti versi asli sesuai permintaan — tetap MAPE klasik,
     * bukan varian lain.
     */
    private function hitungMAPE(array $evaluasi): float
    {
        $total = 0;
        $jumlahValid = 0;

        foreach ($evaluasi as $row) {
            if ($row['aktual'] == 0) {
                continue;
            }

            $total += abs(($row['aktual'] - $row['prediksi']) / $row['aktual']);
            $jumlahValid++;
        }

        return $jumlahValid === 0 ? 0 : round(($total / $jumlahValid) * 100, 2);
    }


    /**
     * Prediksi multi-tahun real-time.
     * Loop per bulan dari tahun_mulai sampai tahun_selesai.
     */
    public function prediksiMultiTahun(
        int $idJenisPajak,
        int $idModel,
        int $tahunMulai,
        int $tahunSelesai
    ): array {
        if ($tahunMulai > $tahunSelesai) {
            throw new \Exception('Tahun mulai tidak boleh lebih besar dari tahun selesai.');
        }

        $hasilPerTahun = [];
        $ringkasan = [];

        $totalBerhasil = 0;
        $totalGagal = 0;

        for ($tahun = $tahunMulai; $tahun <= $tahunSelesai; $tahun++) {
            $totalTahunan = 0;
            $prediksiBulanan = [];
            $mapeTahunan = 0;
            $modelTahunan = '';
            $jumlahBerhasilBulan = 0;
            $jumlahGagalBulan = 0;

            for ($bulan = 1; $bulan <= 12; $bulan++) {
                $periode = sprintf('%d-%02d-01', $tahun, $bulan);
                $periodeCarbon = Carbon::parse($periode);

                try {
                    /*
                     * Memanggil prediksi bulanan secara berurutan.
                     *
                     * Jika prediksi Januari berhasil, maka hasilnya akan disimpan
                     * ke tabel data_pajaks sebagai sumber_data = prediksi.
                     *
                     * Saat Februari dihitung, data prediksi Januari sudah bisa
                     * terbaca sebagai data historis sementara, selama belum ada
                     * data aktual Januari.
                     */
                    $result = $this->prediksiSMA5TahunBulanan(
                        idJenisPajak: $idJenisPajak,
                        idModel: $idModel,
                        periodePrediksi: $periode,
                    );

                    $nilaiPrediksi = (float) $result['nilai_prediksi'];
                    $mape = (float) ($result['model_terbaik']['mape'] ?? 0);
                    $model = $result['model_terbaik']['model'] ?? '-';

                    $prediksiBulanan[] = [
                        'bulan' => $bulan,
                        'nama_bulan' => $this->namaBulanIndonesia($bulan),
                        'periode' => $periode,
                        'nilai_prediksi' => round($nilaiPrediksi, 2),
                        'mape' => round($mape, 2),
                        'model' => $model,
                        'status' => $periodeCarbon->year <= now()->year ? 'Testing' : 'Prediksi',
                        'keterangan' => 'Berhasil dihitung dan disimpan sebagai data prediksi jika belum ada data aktual.',
                    ];

                    $totalTahunan += $nilaiPrediksi;
                    $mapeTahunan += $mape;
                    $modelTahunan = $model;

                    $totalBerhasil++;
                    $jumlahBerhasilBulan++;
                } catch (\Exception $e) {
                    $prediksiBulanan[] = [
                        'bulan' => $bulan,
                        'nama_bulan' => $this->namaBulanIndonesia($bulan),
                        'periode' => $periode,
                        'nilai_prediksi' => null,
                        'mape' => null,
                        'model' => null,
                        'status' => 'Gagal',
                        'error' => $e->getMessage(),
                    ];

                    $totalGagal++;
                    $jumlahGagalBulan++;
                }
            }

            $hasilPerTahun[(string) $tahun] = $prediksiBulanan;

            if ($jumlahBerhasilBulan > 0) {
                $ringkasan[] = [
                    'tahun' => (string) $tahun,
                    'total_prediksi' => round($totalTahunan, 2),
                    'rata_rata_bulan' => round($totalTahunan / $jumlahBerhasilBulan, 2),
                    'mape' => round($mapeTahunan / $jumlahBerhasilBulan, 2),
                    'model' => $modelTahunan,
                    'status' => $tahun <= now()->year ? 'Testing' : 'Prediksi',
                    'jumlah_bulan_berhasil' => $jumlahBerhasilBulan,
                    'jumlah_bulan_gagal' => $jumlahGagalBulan,
                    'keterangan' => 'Ringkasan prediksi tahunan berdasarkan hasil prediksi bulanan yang berhasil dihitung.',
                ];
            } else {
                $ringkasan[] = [
                    'tahun' => (string) $tahun,
                    'total_prediksi' => 0,
                    'rata_rata_bulan' => 0,
                    'mape' => 0,
                    'model' => null,
                    'status' => 'Gagal',
                    'jumlah_bulan_berhasil' => 0,
                    'jumlah_bulan_gagal' => $jumlahGagalBulan,
                    'keterangan' => 'Tidak ada bulan yang berhasil diprediksi pada tahun ini.',
                ];
            }
        }

        return [
            'detail_per_bulan' => $hasilPerTahun,
            'ringkasan_per_tahun' => $ringkasan,
            'meta' => [
                'id_jenis_pajak' => $idJenisPajak,
                'id_model' => $idModel,
                'tahun_mulai' => $tahunMulai,
                'tahun_selesai' => $tahunSelesai,
                'total_berhasil' => $totalBerhasil,
                'total_gagal' => $totalGagal,
                'konsep' => 'Rolling forecast',
                'keterangan' => 'Prediksi dilakukan berurutan per bulan. Hasil prediksi bulan sebelumnya dapat digunakan sebagai data sementara untuk prediksi bulan berikutnya apabila data aktual belum tersedia.',
            ],
        ];
    }

    private function namaBulanIndonesia(int $bulan): string
    {
        $namaBulan = [
            1 => 'Januari',
            2 => 'Februari',
            3 => 'Maret',
            4 => 'April',
            5 => 'Mei',
            6 => 'Juni',
            7 => 'Juli',
            8 => 'Agustus',
            9 => 'September',
            10 => 'Oktober',
            11 => 'November',
            12 => 'Desember',
        ];

        return $namaBulan[$bulan] ?? '-';
    }
}
